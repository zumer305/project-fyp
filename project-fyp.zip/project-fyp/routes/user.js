const express = require("express");
const router = express.Router();
const User = require("../models/user.js");
const wrapAsync = require("../utils/wrapAsync.js");
const passport = require("passport");
const {saveRedirectUrl}=require("../middleware.js");
const userController=require("../controllers/users.js")
// router.get("/signup", userController.renderSignupForm);
// router.post(
//   "/signup",
//   wrapAsync(userController.signup)
// );

router.route("/signup")
.get( userController.renderSignupForm)
.post(
 
  wrapAsync(userController.signup)
);



router.route("/login")
.get(userController.renderLoginForm )
.post(
  saveRedirectUrl,
  passport.authenticate("local", {
    failureRedirect: "/login",
    failureFlash: true, // shows error flash if login fails
  }),
  userController.login
);






router.get("/logout", userController.logout);

module.exports = router;
